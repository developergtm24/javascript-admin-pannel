import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-panels',
  templateUrl: './panels.component.html',
})
export class PanelsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
