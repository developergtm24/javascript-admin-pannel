# AdminCAST

The Most Advanced Bootstrap 4 Admin Template. HTML & Angular 5+ versions. Based on the popular Bootstrap 4 framework, it provides a completely adaptive and perfect interface.

### Demo

* [HTML demo](http://admincast.com/admincast/preview/html/)
* [Angular 5 demo](http://admincast.com/admincast/preview/angular/index)
* [Website](http://admincast.com)
* [Premium version](http://themeforest.net/item/adminca-responsive-bootstrap-4-3-angular-4-admin-dashboard-template/20912589)

![admincast-demo](https://user-images.githubusercontent.com/32571808/34939364-f1391a28-fa04-11e7-8875-f208e2044d5f.jpg)
